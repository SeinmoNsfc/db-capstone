-- TASK 1: Create OrdersView for orders with Quantity > 2
CREATE VIEW OrdersView AS
SELECT OrderID, Quantity, Subtotal AS Cost
FROM littlelemoncapstone.OrderItems
WHERE Quantity > 2;

-- TASK 2: Stored Procedure GetMaxQuantity
DELIMITER $$
CREATE PROCEDURE GetMaxQuantity()
BEGIN
    SELECT MAX(Quantity) AS MaxQuantity
    FROM littlelemoncapstone.OrderItems;
END$$
DELIMITER ;

-- TASK 3: Prepared Statement GetOrderDetail
PREPARE GetOrderDetail FROM
'SELECT OrderID, Quantity, Subtotal AS Cost
 FROM littlelemoncapstone.OrderItems
 WHERE OrderID IN (SELECT OrderID FROM littlelemoncapstone.Orders WHERE CustomerID = ?)';

-- TASK 4: Stored Procedure CancelOrder (delete order)
DELIMITER $$
CREATE PROCEDURE CancelOrder(IN order_id INT)
BEGIN
    DELETE FROM littlelemoncapstone.Orders
    WHERE OrderID = order_id;
END$$
DELIMITER ;

-- TASK 5: Stored Procedure CheckBooking (check if table is booked)
DELIMITER $$
CREATE PROCEDURE CheckBooking(IN booking_date DATE, IN table_number INT)
BEGIN
    DECLARE booking_status VARCHAR(45);
    
    SELECT IF(COUNT(*) > 0, 'Booked', 'Available') INTO booking_status
    FROM littlelemoncapstone.Bookings
    WHERE BookingDate = booking_date AND TableNumber = table_number;
    
    SELECT booking_status AS TableStatus;
END$$
DELIMITER ;

-- TASK 6: Stored Procedure AddValidBooking (add new booking with transaction)
DELIMITER $$
CREATE PROCEDURE AddBooking(IN booking_date DATE, IN table_number INT, IN customer_id INT)
BEGIN
    START TRANSACTION;
    
    -- Check if table is already booked
    DECLARE table_status VARCHAR(45);
    
    SELECT IF(COUNT(*) > 0, 'Booked', 'Available') INTO table_status
    FROM littlelemoncapstone.Bookings
    WHERE BookingDate = booking_date AND TableNumber = table_number;
    
    IF table_status = 'Booked' THEN
        ROLLBACK; -- Table is already booked, cancel booking
        SELECT 'Booking canceled, table is already booked' AS Status;
    ELSE
        INSERT INTO littlelemoncapstone.Bookings (BookingDate, TableNumber, CustomerID)
        VALUES (booking_date, table_number, customer_id);
        COMMIT; -- Booking added successfully
        SELECT 'Booking confirmed' AS Status;
    END IF;
END$$
DELIMITER ;

-- TASK 7: Add bookings sample data
INSERT INTO littlelemoncapstone.Bookings (BookingDate, TableNumber, CustomerID) 
VALUES 
('2022-10-10', 5, 1),
('2022-11-12', 3, 3),
('2022-10-11', 2, 2),
('2022-10-13', 2, 1);
